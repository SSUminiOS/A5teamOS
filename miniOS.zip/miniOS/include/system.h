
// include/linux/sched.h
//SSU struct task_struct {

void minisystem();
void minimkdir(const char *dir_name);
void minimkroot();
void minils();
void minicd();
void minirmdir(const char *dir_name);
